list_y = [2 * x + 4 for x in range(-10, 10)]
print(list_y)
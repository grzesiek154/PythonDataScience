a = 10
b = 0
c = a / b
print(c)

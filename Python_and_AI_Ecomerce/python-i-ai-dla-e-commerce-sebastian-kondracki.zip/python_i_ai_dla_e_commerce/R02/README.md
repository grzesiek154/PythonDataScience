# Część I Python: krótki wstęp do efektywnego programowania
## Rozdział 2 Struktury danych
### Wymagane pakiety

+ listing_2_2.py
    + pip install python-Levenshtein
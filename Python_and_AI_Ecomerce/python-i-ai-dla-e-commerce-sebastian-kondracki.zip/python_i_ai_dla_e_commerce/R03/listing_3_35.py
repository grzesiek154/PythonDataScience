try:
    a = 10
    b = 0
    c = a / b
except:
    c = None
    print("Wystąpił błąd dzielenia przez zero")

print(c)

print("\033[94mKolor niebieski\033[0m")
print("\033[94m%s\033[0m" % ("Kolor niebieski uzyskany za pomocą bardziej czytelnego kodu"))
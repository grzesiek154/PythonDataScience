customer = dict(first_name="J.", last_name="Kowalski", pesel="05210722588", nip="7578390197")
customer["first_name"] = "Jan"
customer["salary"] = 5000
print(customer)
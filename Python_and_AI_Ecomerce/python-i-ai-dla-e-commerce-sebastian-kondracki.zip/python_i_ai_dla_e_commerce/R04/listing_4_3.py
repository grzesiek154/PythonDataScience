import numpy as np

a = np.arange(0, 12, 1)
print(a)
b = a.reshape(3,4)
print(b)
c = np.arange(0, 16).reshape(4,4)
print(c)
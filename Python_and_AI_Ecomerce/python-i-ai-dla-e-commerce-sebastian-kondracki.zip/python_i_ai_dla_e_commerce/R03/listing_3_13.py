int_number = 10
float_number = 10.5
line1 = "Format liczby [d]:  %d" % (int_number)
line2 = "Format liczby [o]:  %o" % (int_number)
line3 = "Format liczby [x]:  %x" % (int_number)
line4 = "Format liczby [e]:  %e" % (float_number)
line5 = "Format liczby [f]:  %f" % (float_number)
print(line1)
print(line2)
print(line3)
print(line4)
print(line5)
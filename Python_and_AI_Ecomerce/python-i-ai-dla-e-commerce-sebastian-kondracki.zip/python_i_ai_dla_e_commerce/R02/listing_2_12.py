date = (2021, 3, 17)
year, month, day = date
print(str(year), str(month), str(day))
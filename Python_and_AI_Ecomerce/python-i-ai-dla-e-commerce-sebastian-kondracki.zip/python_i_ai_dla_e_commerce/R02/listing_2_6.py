customers = ["Kowalski", "Nowak", "Wiśniewski", "Kowalczyk"]

print("Pierwszy element:", customers[0])
for customer in customers:
    print(customer)
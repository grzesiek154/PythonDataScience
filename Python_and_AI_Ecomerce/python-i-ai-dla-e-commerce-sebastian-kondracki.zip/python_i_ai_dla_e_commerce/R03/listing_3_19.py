state = (True,False,None)
items = []

items.append({"product" : "Produkt 1", "price" : 22.4, "states" : state}) 
items.append({"product" : "Produkt 2", "price" : 15.4, "states" : state})
customer = {"first_name" : "Sebastian", "last_name" : "Kondracki", "items" : items}

print(customer)
first_name = "Sebastian"
line = "Witaj! %s" % (first_name)
print(line)
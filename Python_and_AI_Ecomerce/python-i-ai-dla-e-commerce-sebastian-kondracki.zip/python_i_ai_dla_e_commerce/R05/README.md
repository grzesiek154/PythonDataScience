# Część I Python: krótki wstęp do efektywnego programowania
## Rozdział 5 Bazy danych i repozytoria danych
### Wymagane pakiety

pip install requests
pip install geopy
pip install elasticsearch==7.14.0


# Część III Przepisy
## Rozdział 14 Systemy rekomendacji, czyli jak zwiększyć koszyk
### Wymagane pakiety

pip install pandas
pip install scikit-learn
pip install langdetect

pip install spacy
python -m spacy download pl_core_news_md

pip install mlxtend
first_name = "Sebastian"
last_name = "Kondracki"
line = "Witaj! %s %s" % (first_name, last_name)
print(line)
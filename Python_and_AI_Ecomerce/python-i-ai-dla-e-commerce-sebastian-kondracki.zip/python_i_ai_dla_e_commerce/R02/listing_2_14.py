customers = set(['Kowalczyk', 'Kowalski', 'Kowalczyk', 'Nowak'])
      
print(customers)
customers = set(('Kowalczyk', 'Kowalski', 'Kowalczyk', 'Nowak'))
print(customers)
# Część I Python: krótki wstęp do efektywnego programowania
## Rozdział 3 Niezbędnik programisty
### Wymagane pakiety

+ listing_3_18.py, listing_3_20.py, listing_3_21.py, listing_3_25.py 
    + pip install rich
+ listing_3_22.py, listing_3_23.py, listing_3_24.py  
    + pip install tabulate
customer_1 = dict(
    [
        ("first_name", "Jan"),
        ("last_name", "Kowalski"),
        ("pesel", "05210722588"),
        ("nip", "7578390197"),
    ]
)
print(customer_1)

customer_2 = dict(
    (
        ["first_name", "Anna"],
        ["last_name", "Nowak"],
        ["pesel", "07280722588"],
        ["nip", "7588398117"],
    )
)
print(customer_2)

numbers = [1, 2, 4, 5, 100, 1000]
print(list(map(lambda x: 3*x, numbers)))
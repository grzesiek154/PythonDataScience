customers = []

customers.append("Kowalski")
customers.append("Nowak")
customers.append("Wiśniewski")
customers.append("Kowalczyk")
print(customers)
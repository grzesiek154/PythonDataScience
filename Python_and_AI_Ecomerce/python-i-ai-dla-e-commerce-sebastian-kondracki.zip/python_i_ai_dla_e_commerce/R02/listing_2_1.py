description = '''Ilość lekcji: 57
      Czas trwania: 10:47:52
      Format: Zip
      Rok nagrania: 2021-01-21
      ISBN: 978-83-283-7884-1, 9788328378841
      Data wydania: 2021-01-21
      Numer z katalogu: 139860'''
      
print("Metoda 1:")
print(description)
description = 'Ilość lekcji: 57\nCzas trwania: 10:47:52\nFormat:Zip\nRok nagrania: 2021-01-21\nISBN: 978-83-283-7884-1,9788328378841\nData wydania: 2021-01-21\nNumer z katalogu: 139860'
print("Metoda 2:")
print(description)
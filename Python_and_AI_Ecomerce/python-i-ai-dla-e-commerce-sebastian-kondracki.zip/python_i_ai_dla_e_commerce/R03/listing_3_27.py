seconds = lambda h, m, s: (h * 60 * 60) + (m * 60) + s
print(seconds(5, 1, 2))
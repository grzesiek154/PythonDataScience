first_name = "Sebastian"
line = "Witaj! {}".format(first_name)
print(line)
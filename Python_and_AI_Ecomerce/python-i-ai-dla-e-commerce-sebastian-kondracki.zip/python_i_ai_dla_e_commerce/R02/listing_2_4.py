customers = ["Kowalski", "Nowak", "Wiśniewski"]
print(customers)
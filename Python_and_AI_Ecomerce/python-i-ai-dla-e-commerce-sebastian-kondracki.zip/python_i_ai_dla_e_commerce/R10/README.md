# Część III Przepisy
## Rozdział 10 Web scraping
### Wymagane pakiety

pip install requests
pip install beautifulsoup4
pip install scrapy
pip install selenium
pip install extruct

### Uruchamianie scraper'ów

+ listing_10_4.py - **scrapy runspider listing_10_4.py**
+ listing_10_6.py - **scrapy runspider listing_10_6.py -o listing_10_6.csv -t csv**
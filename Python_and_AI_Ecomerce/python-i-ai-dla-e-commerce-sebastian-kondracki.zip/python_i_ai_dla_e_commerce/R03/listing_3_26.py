kilo = lambda x: x * 1000

print(kilo(2))
print((lambda x: x * 1000)(5))
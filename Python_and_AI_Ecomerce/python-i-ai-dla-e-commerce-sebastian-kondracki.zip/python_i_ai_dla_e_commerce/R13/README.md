# Część III Przepisy
## Rozdział 13 Klasyfikacja w służbie niskiej rezygnacji
### Wymagane pakiety

pip install pandas
pip install scikit-learn
pip install seaborn
pip install matplotlib
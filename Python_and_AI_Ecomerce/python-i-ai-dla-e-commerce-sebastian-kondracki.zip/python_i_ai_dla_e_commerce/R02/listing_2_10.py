days = "poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"
print(days)
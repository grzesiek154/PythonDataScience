list_y = [2 * x + 4 for x in range(-10, 10) if (2 * x + 4) > 0]
print(list_y)
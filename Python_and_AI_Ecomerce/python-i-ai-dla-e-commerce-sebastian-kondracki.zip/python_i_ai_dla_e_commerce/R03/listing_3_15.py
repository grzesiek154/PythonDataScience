int_number = 10
float_number = 10.5
line1 = "Format liczby [d]:  {:d}".format(int_number)
line2 = "Format liczby [o]:  {:o}".format(int_number)
line3 = "Format liczby [x]:  {:x}".format(int_number)
line4 = "Format liczby [e]:  {:e}".format(float_number)
line5 = "Format liczby [f]:  {:f}".format(float_number)
print(line1)
print(line2)
print(line3)
print(line4)
print(line5)
import pandas as pd

df = pd.read_csv(
    "Kwartalne_wskazniki_cen_towarow_i_uslug_konsumpcyjnych_od_1995__rokuu.csv"
)
print(df)

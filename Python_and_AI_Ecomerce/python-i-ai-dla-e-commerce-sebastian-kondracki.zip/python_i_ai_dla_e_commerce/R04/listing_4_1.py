import numpy as np

a1 = np.array([1, 2, 3, 4])
print(a1)
print("Rozmiar:", a1.shape)
print("Element 0:", a1[0])

a2 = np.array([[5, 6], [7, 8]])
print(a2)
print("Rozmiar:", a2.shape)
print("Element 0,1:", a2[0, 1])
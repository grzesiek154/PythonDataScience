customer = dict(first_name="Jan", last_name="Kowalski", pesel="05210722588", nip="7578390197")
print(customer)
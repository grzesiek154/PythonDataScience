keys = ("first_name", "last_name", "pesel", "nip")
values = ("Anna", "Nowak", "07280722588", "7588398117")
customer = dict(zip(keys, values))
print(customer)
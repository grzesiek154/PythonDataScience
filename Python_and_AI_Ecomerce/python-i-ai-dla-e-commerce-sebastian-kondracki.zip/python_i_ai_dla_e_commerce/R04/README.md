# Część I Python: krótki wstęp do efektywnego programowania
## Rozdział 4 NumPy i Pandas w akcji
### Wymagane pakiety

pip install numpy
pip install pandas
pip install matplotlib

+ listing_4_17.py
    + pip install opencv-python
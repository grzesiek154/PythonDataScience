# Część I Python: krótki wstęp do efektywnego programowania
## Rozdział 1 Narzędzia
### Wymagane pakiety

+ listing_1_2.py
    + pip install openpyxl
+ listing_1_3.py
    + pip install tabulate
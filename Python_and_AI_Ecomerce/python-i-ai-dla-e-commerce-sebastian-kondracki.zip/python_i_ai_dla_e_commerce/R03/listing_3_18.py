from rich import print
print("Kolory, pogrubienie? [bold magenta]Nie ma problemu![/bold magenta]!")
print("Emotikony? Proszę bardzo!",":smiley: :vampire: :pile_of_poo: :thumbs_up: :raccoon:")
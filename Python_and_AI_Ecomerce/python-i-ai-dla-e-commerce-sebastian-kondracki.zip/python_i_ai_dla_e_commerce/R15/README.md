# Część III Przepisy
## Rozdział 15 Uczenie nadzorowane — klasyfikatory
### Wymagane pakiety

pip install Flask
pip install flask-sqlalchemy
pip install flask-expects-json
pip install networkx

### Uruchamianie micro serwisów

+ listing_15_1.py
    + **export FLASK_APP=listing_15_1.py**
    + **flask run**
+ listing_15_2.py
    + **export FLASK_APP=listing_15_2.py**
    + **flask run**
+ listing_15_3.py
    + **export FLASK_APP=listing_15_3.py**
    + **flask run**
+ listing_15_4.py
    + **export FLASK_APP=listing_15_4.py**
    + **flask run**
+ listing_15_5.py
    + **export FLASK_APP=listing_15_5.py**
    + **flask run**
+ listing_15_9.py
    + **export FLASK_APP=listing_15_9.py**
    + **flask run**
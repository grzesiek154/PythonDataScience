import numpy as np

a = np.random.rand(1000000, 5)

print("shape:", a.shape)
print("size: ", a.size)
print("ndim: ", a.ndim)
print("dtype:", a.dtype)
print("len: ", len(a))
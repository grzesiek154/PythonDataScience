import numpy as np

a = np.loadtxt("a.txt")
print(a)
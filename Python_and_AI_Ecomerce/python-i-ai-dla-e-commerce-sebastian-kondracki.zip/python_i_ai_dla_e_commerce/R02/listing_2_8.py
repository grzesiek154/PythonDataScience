customers = ["Kowalski", "Nowak", "Wiśniewski"]
customers.append("Kowalczyk")
customers.append("Adamowicz")
print(customers)
print(customers.pop())
print(customers.pop())
print(customers.pop())

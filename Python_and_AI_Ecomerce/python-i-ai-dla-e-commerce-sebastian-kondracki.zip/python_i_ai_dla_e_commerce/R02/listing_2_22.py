customer = dict(first_name="Jan", last_name="Kowalski", pesel="05210722588", nip="7578390197")

for value in customer.values():
    print(value)
for key in customer.keys():
    print(key)